import React from 'react';
import { ArrowRight, Mail, Sparkles, MapPin, GraduationCap, Github, Linkedin, Terminal, ChevronDown } from 'lucide-react';
import { personalData } from '../data/portfolioData';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background Ambient Glow Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 sm:w-[550px] h-96 sm:h-[550px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-slow"></div>
      <div className="absolute top-1/3 right-10 w-72 sm:w-[400px] h-72 sm:h-[400px] bg-purple-500/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute bottom-10 left-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div className="max-w-6xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Hero Column */}
          <div className="lg:col-span-7 text-center lg:text-left space-y-6">
            
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-800/80 border border-cyan-500/30 text-xs font-medium text-cyan-300 shadow-sm shadow-cyan-500/10">
              <Sparkles size={14} className="text-cyan-400" />
              <span>Welcome to my digital portfolio</span>
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
              <span className="text-slate-400">JECRC University</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-3">
              <h2 className="text-sm sm:text-base font-semibold text-slate-400 uppercase tracking-widest">
                Hello, I'm
              </h2>
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white">
                <span className="text-gradient">ONIK</span>
                <br />
                <span className="text-white">BAGHERWAL</span>
              </h1>
              <p className="text-lg sm:text-xl font-semibold text-cyan-400 flex items-center justify-center lg:justify-start gap-2 pt-1">
                <span className="text-white/40 font-mono">&gt;</span>
                <span>B.Tech Student | AI & Technology Enthusiast</span>
              </p>
            </div>

            {/* Short Professional Introduction */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed mx-auto lg:mx-0">
              I am a B.Tech student interested in technology, artificial intelligence, web development, and digital productivity. I am actively learning modern technologies and building practical, impactful projects.
            </p>

            {/* Key Meta Badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2 text-xs text-slate-300">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-white/10">
                <GraduationCap size={14} className="text-cyan-400" />
                <span>JECRC University, Jaipur</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-white/10">
                <MapPin size={14} className="text-purple-400" />
                <span>Jaipur, Rajasthan</span>
              </div>
            </div>

            {/* Action Buttons: View Projects & Contact Me */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
              <a
                href="#projects"
                className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:-translate-y-0.5 transition-all duration-200 group"
              >
                <span>View Projects</span>
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="#contact"
                className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold text-sm border border-white/10 hover:border-cyan-500/40 transition-all duration-200 hover:-translate-y-0.5"
              >
                <Mail size={16} className="text-cyan-400" />
                <span>Contact Me</span>
              </a>
            </div>

            {/* Social Links Row */}
            <div className="flex items-center justify-center lg:justify-start gap-4 pt-3">
              <span className="text-xs text-slate-400 uppercase tracking-wider font-mono">Connect:</span>
              <a
                href={personalData.github}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-white/10 hover:border-cyan-400/40 transition-colors"
                aria-label="GitHub Profile"
              >
                <Github size={18} />
              </a>
              <a
                href={personalData.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 border border-white/10 hover:border-cyan-400/40 transition-colors"
                aria-label="LinkedIn Profile"
              >
                <Linkedin size={18} />
              </a>
              <a
                href={`mailto:${personalData.email}`}
                className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-purple-400 border border-white/10 hover:border-purple-400/40 transition-colors"
                aria-label="Email Me Directly"
              >
                <Mail size={18} />
              </a>
            </div>

          </div>

          {/* Hero Visual Card / Interactive Tech Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md">
              {/* Decorative border backdrop glow */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-cyan-500 to-purple-600 opacity-30 blur-xl"></div>

              <div className="relative rounded-2xl glass-card p-6 sm:p-7 border border-white/15 space-y-6">
                
                {/* Terminal Header */}
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500/80"></span>
                    <span className="w-3 h-3 rounded-full bg-amber-500/80"></span>
                    <span className="w-3 h-3 rounded-full bg-emerald-500/80"></span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-slate-400 font-mono">
                    <Terminal size={12} className="text-cyan-400" />
                    <span>student_profile.json</span>
                  </div>
                </div>

                {/* Code-like presentation */}
                <div className="font-mono text-xs sm:text-sm space-y-2 text-slate-300 leading-relaxed bg-black/40 p-4 rounded-xl border border-white/5">
                  <p><span className="text-purple-400">const</span> student = &#123;</p>
                  <p className="pl-4"><span className="text-cyan-400">name</span>: <span className="text-emerald-300">"ONIK BAGHERWAL"</span>,</p>
                  <p className="pl-4"><span className="text-cyan-400">degree</span>: <span className="text-emerald-300">"B.Tech"</span>,</p>
                  <p className="pl-4"><span className="text-cyan-400">university</span>: <span className="text-emerald-300">"JECRC University"</span>,</p>
                  <p className="pl-4"><span className="text-cyan-400">city</span>: <span className="text-emerald-300">"Jaipur, Rajasthan"</span>,</p>
                  <p className="pl-4"><span className="text-cyan-400">focus</span>: [</p>
                  <p className="pl-8 text-amber-300">"Artificial Intelligence",</p>
                  <p className="pl-8 text-amber-300">"Generative AI",</p>
                  <p className="pl-8 text-amber-300">"Web Development",</p>
                  <p className="pl-8 text-amber-300">"Digital Productivity"</p>
                  <p className="pl-4">],</p>
                  <p className="pl-4"><span className="text-cyan-400">status</span>: <span className="text-emerald-400">"Building & Learning 🚀"</span></p>
                  <p>&#125;;</p>
                </div>

                {/* Quick Feature Stats */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <span className="block text-xl font-bold text-cyan-400">3+</span>
                    <span className="text-xs text-slate-400">Core Projects</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <span className="block text-xl font-bold text-purple-400">8+</span>
                    <span className="text-xs text-slate-400">Key Tech Skills</span>
                  </div>
                </div>

                {/* University Highlight Tag */}
                <div className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-950/40 to-indigo-950/40 border border-cyan-500/20 text-xs">
                  <span className="text-slate-300 font-medium">📍 Campus</span>
                  <span className="text-cyan-300 font-semibold">JECRC University, Jaipur</span>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Down Arrow indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-1 text-slate-500 hover:text-cyan-400 transition-colors">
        <span className="text-[10px] uppercase font-mono tracking-wider">Scroll</span>
        <a href="#about" aria-label="Scroll to About Section">
          <ChevronDown size={18} className="animate-bounce" />
        </a>
      </div>
    </section>
  );
}
