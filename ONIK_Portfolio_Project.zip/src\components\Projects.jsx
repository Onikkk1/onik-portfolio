import React, { useState } from 'react';
import { 
  FolderGit2, 
  ArrowUpRight, 
  Sparkles, 
  ExternalLink, 
  Github, 
  Code2, 
  Layers, 
  Eye 
} from 'lucide-react';
import { projectsData } from '../data/portfolioData';
import ProjectModal from './ProjectModal';

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <section id="projects" className="py-24 px-4 sm:px-6 lg:px-8 relative">
      {/* Background ambient decorative shapes */}
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <FolderGit2 size={13} />
            <span>Featured Work</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Featured <span className="text-gradient">Projects</span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
            Practical applications showcasing my skills in artificial intelligence, modern web development, and digital productivity.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {projectsData.map((project) => (
            <div
              key={project.id}
              className="glass-card rounded-2xl flex flex-col justify-between overflow-hidden border border-white/10 hover:border-cyan-500/50 group transition-all duration-300"
            >
              {/* Card Top / Visual Banner */}
              <div className="p-6 pb-0 space-y-4">
                
                {/* Visual Category Banner */}
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-md bg-cyan-500/10 text-cyan-300 text-xs font-medium border border-cyan-500/20">
                    {project.category}
                  </span>
                  <span className="text-xs font-mono text-slate-500">0{project.id}</span>
                </div>

                {/* Project Title & Tagline */}
                <div className="space-y-1.5">
                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors flex items-center justify-between">
                    <span>{project.title}</span>
                  </h3>
                  <p className="text-xs font-medium text-cyan-400">
                    {project.tagline}
                  </p>
                </div>

                {/* Short Description */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {project.description}
                </p>

              </div>

              {/* Card Bottom: Technologies & Action Button */}
              <div className="p-6 pt-5 space-y-5 border-t border-white/5 mt-5 bg-black/20">
                
                {/* Technologies Used */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block">
                    Technologies Used
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {project.technologies.slice(0, 4).map((tech) => (
                      <span
                        key={tech}
                        className="px-2.5 py-1 rounded-md bg-white/5 border border-white/5 text-[11px] font-mono text-slate-300"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 4 && (
                      <span className="px-2 py-1 rounded-md bg-white/5 text-[11px] font-mono text-slate-400">
                        +{project.technologies.length - 4}
                      </span>
                    )}
                  </div>
                </div>

                {/* View Project Button */}
                <button
                  onClick={() => setSelectedProject(project)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 hover:from-cyan-500 hover:to-indigo-600 text-cyan-300 hover:text-white border border-cyan-500/40 hover:border-transparent text-xs font-semibold shadow-sm transition-all duration-200 group/btn"
                >
                  <Eye size={15} className="group-hover/btn:scale-110 transition-transform" />
                  <span>View Project Details</span>
                  <ArrowUpRight size={14} className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                </button>

              </div>
            </div>
          ))}
        </div>

        {/* Project Modal */}
        {selectedProject && (
          <ProjectModal
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
          />
        )}

        {/* GitHub Repository Callout */}
        <div className="text-center pt-4">
          <p className="text-xs text-slate-400">
            Interested in exploring the code architectures?{' '}
            <a
              href="https://github.com/onik-bagherwal"
              target="_blank"
              rel="noreferrer"
              className="text-cyan-400 hover:underline font-semibold inline-flex items-center gap-1"
            >
              <span>Visit my GitHub Profile</span>
              <ArrowUpRight size={13} />
            </a>
          </p>
        </div>

      </div>
    </section>
  );
}
