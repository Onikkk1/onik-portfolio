import React, { useState } from 'react';
import { 
  Trophy, 
  Award, 
  BookOpen, 
  CheckCircle2, 
  Medal, 
  Calendar, 
  PlusCircle, 
  ExternalLink,
  Sparkles 
} from 'lucide-react';
import { achievementsData } from '../data/portfolioData';

export default function Achievements() {
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Certifications', 'Hackathons', 'Courses', 'Awards', 'Other Achievements'];

  const getAchievementIcon = (iconName) => {
    switch (iconName) {
      case 'Award': return <Award size={22} className="text-cyan-400" />;
      case 'BookOpen': return <BookOpen size={22} className="text-purple-400" />;
      case 'Trophy': return <Trophy size={22} className="text-amber-400" />;
      case 'CheckCircle2': return <CheckCircle2 size={22} className="text-emerald-400" />;
      case 'Medal': return <Medal size={22} className="text-rose-400" />;
      case 'Sparkles': return <Sparkles size={22} className="text-cyan-400" />;
      default: return <Award size={22} className="text-cyan-400" />;
    }
  };

  const filteredAchievements = activeCategory === 'All'
    ? achievementsData
    : achievementsData.filter(item => item.category === activeCategory);

  return (
    <section id="achievements" className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-6xl mx-auto space-y-14">
        
        {/* Section Heading */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-semibold uppercase tracking-wider">
            <Trophy size={13} />
            <span>Milestones & Recognitions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            My <span className="text-gradient">Achievements</span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
            Certifications, hackathons, competitive milestones, and coursework achievements completed during my academic journey.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-amber-500 to-indigo-600 text-white shadow-md shadow-amber-500/20 scale-105'
                  : 'glass-pill text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Achievements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAchievements.map((item) => (
            <div
              key={item.id}
              className="glass-card p-6 rounded-2xl flex flex-col justify-between border border-white/10 hover:border-amber-500/40 group transition-all duration-300 space-y-5"
            >
              <div className="space-y-4">
                {/* Header: Icon + Category Badge */}
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 group-hover:scale-110 transition-transform">
                    {getAchievementIcon(item.icon)}
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-300 text-[11px] font-mono border border-amber-500/20">
                    {item.category}
                  </span>
                </div>

                {/* Title & Issuer */}
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs font-medium text-cyan-400">
                    {item.issuer}
                  </p>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-300 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Date Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-white/5 text-[11px] text-slate-400 font-mono">
                <div className="flex items-center gap-1.5">
                  <Calendar size={13} className="text-slate-500" />
                  <span>{item.date}</span>
                </div>
                <span className="text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 size={12} />
                  <span>Verified</span>
                </span>
              </div>
            </div>
          ))}

          {/* "+ Add More Achievements" Info Card */}
          <div className="p-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] flex flex-col justify-center items-center text-center space-y-3 p-8">
            <div className="w-12 h-12 rounded-full bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <PlusCircle size={24} />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-white">More Milestones Coming Soon</h4>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                Add certifications, hackathons, and courses seamlessly inside <code className="text-cyan-300 text-[11px] bg-white/5 px-1 py-0.5 rounded">src/data/portfolioData.js</code>.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
