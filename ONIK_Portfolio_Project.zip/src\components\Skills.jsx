import React, { useState } from 'react';
import { 
  Brain, 
  Sparkles, 
  FileCode2, 
  Code, 
  Globe, 
  Layout, 
  Palette, 
  Zap, 
  CheckCircle, 
  Layers 
} from 'lucide-react';
import { skillsData } from '../data/portfolioData';

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'AI & Emerging Tech', 'Programming', 'Web & Frontend', 'Tools & Systems'];

  const getSkillIcon = (iconName) => {
    switch (iconName) {
      case 'Brain': return <Brain size={24} className="text-cyan-400" />;
      case 'Sparkles': return <Sparkles size={24} className="text-purple-400" />;
      case 'FileCode2': return <FileCode2 size={24} className="text-blue-400" />;
      case 'Code': return <Code size={24} className="text-amber-400" />;
      case 'Globe': return <Globe size={24} className="text-emerald-400" />;
      case 'Layout': return <Layout size={24} className="text-rose-400" />;
      case 'Palette': return <Palette size={24} className="text-indigo-400" />;
      case 'Zap': return <Zap size={24} className="text-yellow-400" />;
      default: return <Code size={24} className="text-cyan-400" />;
    }
  };

  const filteredSkills = activeCategory === 'All'
    ? skillsData
    : skillsData.filter((skill) => skill.category === activeCategory);

  return (
    <section id="skills" className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-6xl mx-auto space-y-14">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Layers size={13} />
            <span>Technical Capabilities</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            My <span className="text-gradient">Skills</span> & Proficiencies
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
            Core technologies, programming languages, and intelligent tools I use to build modern digital solutions.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-md shadow-cyan-500/25 scale-105'
                  : 'glass-pill text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredSkills.map((skill, index) => (
            <div
              key={skill.name}
              className="glass-card p-6 rounded-2xl flex flex-col justify-between space-y-5 hover:border-cyan-500/50 group transition-all duration-300"
            >
              <div className="space-y-4">
                {/* Card Top: Icon & Category Tag */}
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 group-hover:scale-110 transition-transform">
                    {getSkillIcon(skill.icon)}
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-white/5 text-[11px] font-mono text-slate-400 border border-white/5">
                    {skill.level}
                  </span>
                </div>

                {/* Skill Name & Description */}
                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {skill.name}
                  </h3>
                  <span className="text-xs text-slate-400 font-medium">
                    {skill.category}
                  </span>
                  <p className="text-xs text-slate-300 pt-2 leading-relaxed">
                    {skill.description}
                  </p>
                </div>
              </div>

              {/* Proficiency Bar */}
              <div className="space-y-1.5 pt-2 border-t border-white/5">
                <div className="flex justify-between text-[11px] font-mono text-slate-400">
                  <span>Proficiency</span>
                  <span className="text-cyan-400 font-semibold">{skill.proficiency}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 rounded-full transition-all duration-1000"
                    style={{ width: `${skill.proficiency}%` }}
                  ></div>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Additional Student Tech Summary */}
        <div className="p-6 rounded-2xl glass-card border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <h4 className="text-base font-bold text-white">Always Expanding My Toolkit</h4>
            <p className="text-xs sm:text-sm text-slate-400">
              Continuously exploring new Python AI libraries, React ecosystem tools, and developer productivity workflows.
            </p>
          </div>
          <a
            href="#projects"
            className="px-5 py-2.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-cyan-400 border border-cyan-500/30 shrink-0 transition-colors"
          >
            See Skills In Action →
          </a>
        </div>

      </div>
    </section>
  );
}
