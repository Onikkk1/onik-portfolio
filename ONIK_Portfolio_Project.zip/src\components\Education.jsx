import React from 'react';
import { GraduationCap, MapPin, Calendar, BookOpen, CheckCircle, Award } from 'lucide-react';
import { educationData } from '../data/portfolioData';

export default function Education() {
  return (
    <section id="education" className="py-24 px-4 sm:px-6 lg:px-8 relative">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Section Heading */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-semibold uppercase tracking-wider">
            <GraduationCap size={13} />
            <span>Academic Background</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            My <span className="text-gradient">Education</span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
            Formal engineering foundations and focused learning areas in computer science and modern software.
          </p>
        </div>

        {/* Education Timeline / Detailed Card */}
        <div className="max-w-4xl mx-auto">
          {educationData.map((item, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 sm:p-10 border border-white/10 hover:border-cyan-500/40 relative overflow-hidden transition-all duration-300 space-y-8"
            >
              {/* Corner decorative accent glow */}
              <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl"></div>

              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-white/10 pb-6">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-md bg-cyan-500/20 text-cyan-300 text-xs font-semibold uppercase tracking-wider border border-cyan-500/30">
                      {item.badge}
                    </span>
                    <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      {item.status}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight pt-1">
                    {item.degree}
                  </h3>
                  <div className="text-lg font-semibold text-cyan-400">
                    {item.college}
                  </div>
                </div>

                <div className="flex flex-col sm:items-end gap-2 text-xs sm:text-sm text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <MapPin size={15} className="text-purple-400" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar size={15} className="text-cyan-400" />
                    <span>{item.year || '2023 - 2027'}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                {item.description}
              </p>

              {/* Learning Areas / Relevant Coursework */}
              <div className="space-y-4 pt-2">
                <div className="flex items-center gap-2 text-xs uppercase font-mono tracking-wider text-slate-400">
                  <BookOpen size={14} className="text-cyan-400" />
                  <span>Relevant Learning Areas & Coursework</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {item.highlights.map((course, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-900/60 border border-white/5 hover:border-cyan-500/30 transition-colors group"
                    >
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500/20 transition-colors">
                        <CheckCircle size={15} />
                      </div>
                      <span className="text-xs sm:text-sm text-slate-200 font-medium">{course}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* University Campus Highlights Footer */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-slate-900/80 to-slate-800/50 border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <Award size={16} className="text-amber-400" />
                  <span>Focusing on practical projects, coding agility, and technology research</span>
                </div>
                <span className="text-cyan-400 font-mono">Jaipur • Rajasthan</span>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
