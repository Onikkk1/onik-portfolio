import React from 'react';
import { Brain, Globe, Zap, Compass, CheckCircle2, Award, BookOpen } from 'lucide-react';
import { personalData } from '../data/portfolioData';

export default function About() {
  const pillars = [
    {
      title: "Artificial Intelligence & Gen AI",
      icon: Brain,
      color: "cyan",
      borderColor: "border-cyan-500/30",
      textColor: "text-cyan-400",
      bgGlow: "bg-cyan-500/10",
      description: "Fascinated by neural architectures, large language models, and practical AI implementations that automate complex reasoning tasks."
    },
    {
      title: "Modern Web Development",
      icon: Globe,
      color: "blue",
      borderColor: "border-blue-500/30",
      textColor: "text-blue-400",
      bgGlow: "bg-blue-500/10",
      description: "Dedicated to crafting snappy, accessible, and responsive user interfaces using HTML, CSS, JavaScript, and modern component frameworks."
    },
    {
      title: "Digital Productivity & Systems",
      icon: Zap,
      color: "purple",
      borderColor: "border-purple-500/30",
      textColor: "text-purple-400",
      bgGlow: "bg-purple-500/10",
      description: "Passionate about structured workflow design, study systems, task prioritization, and leveraging smart tools to maximize daily output."
    }
  ];

  const highlights = [
    "Undergraduate B.Tech student at JECRC University, Jaipur Rajasthan",
    "Continuous learner exploring modern JavaScript, Python, and AI toolsets",
    "Believer in learning by doing: creating practical projects rather than pure theory",
    "Eager to collaborate on open-source, hackathons, and software projects"
  ];

  return (
    <section id="about" className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Section Title */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Compass size={13} />
            <span>Get To Know Me</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            About <span className="text-gradient">Me</span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
            A glimpse into my journey, interests, and how I approach technology as a student engineer.
          </p>
        </div>

        {/* Narrative & Highlights Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Story */}
          <div className="lg:col-span-7 glass-card p-8 rounded-2xl space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
              Engineering My Path Through Code & Curiosity
            </h3>

            <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                Hello! I am <strong className="text-white">ONIK BAGHERWAL</strong>, an enthusiastic B.Tech student currently studying at <span className="text-cyan-400 font-medium">JECRC University in Jaipur, Rajasthan</span>.
              </p>
              <p>
                My passion lies at the intersection of <strong className="text-white">technology, artificial intelligence, web development</strong>, and <strong className="text-white">digital productivity</strong>. I believe that modern software is not just about writing syntax—it is about building intuitive experiences that make people more capable, focused, and creative.
              </p>
              <p>
                Whether it is building modern frontend websites with React and Tailwind, exploring Python scripts for AI and machine learning tasks, or designing optimized study systems, I enjoy translating theoretical university learning into real, working prototypes.
              </p>
            </div>

            {/* Bullet Highlights */}
            <div className="pt-4 border-t border-white/10 space-y-2.5">
              {highlights.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle2 size={18} className="text-cyan-400 shrink-0 mt-0.5" />
                  <span className="text-xs sm:text-sm text-slate-300">{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Side Info Cards */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* College & Degree Spotlight */}
            <div className="glass-card p-6 rounded-2xl border border-cyan-500/20 bg-gradient-to-br from-cyan-950/20 to-slate-900/80 space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400">
                  <BookOpen size={24} />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">Current Academic Home</h4>
                  <p className="text-xs text-slate-400">Jaipur, Rajasthan</p>
                </div>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                Enrolled in the <span className="text-cyan-300 font-medium">Bachelor of Technology (B.Tech)</span> program at <span className="text-white font-semibold">JECRC University</span>, actively building technical aptitude and participating in tech initiatives.
              </p>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              {personalData.stats.map((stat, i) => (
                <div key={i} className="glass-card p-4 rounded-xl text-center space-y-1">
                  <span className="text-xs text-slate-400 block">{stat.label}</span>
                  <span className="text-sm sm:text-base font-bold text-white block">{stat.value}</span>
                </div>
              ))}
            </div>

            {/* Future Aspirations Card */}
            <div className="glass-card p-5 rounded-2xl space-y-2 border border-purple-500/20 bg-gradient-to-br from-purple-950/20 to-slate-900/80">
              <div className="flex items-center gap-2 text-purple-400 font-semibold text-xs uppercase tracking-wider">
                <Award size={14} />
                <span>My Driving Philosophy</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 italic">
                "Stay curious, iterate fast, and leverage modern digital tools to solve everyday challenges."
              </p>
            </div>

          </div>

        </div>

        {/* 3 Core Focus Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          {pillars.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 rounded-2xl relative overflow-hidden group space-y-4 hover:border-white/20 transition-all duration-300"
              >
                <div className={`w-12 h-12 rounded-xl ${pillar.bgGlow} flex items-center justify-center ${pillar.textColor} group-hover:scale-110 transition-transform`}>
                  <IconComponent size={24} />
                </div>
                <h4 className="text-base font-bold text-white tracking-wide">
                  {pillar.title}
                </h4>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {pillar.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
