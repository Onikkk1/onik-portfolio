export const personalData = {
  name: "ONIK BAGHERWAL",
  role: "B.Tech CSE Student",
  college: "JECRC UNIVERSITY, Jaipur",
  degree: "Bachelor of Technology (B.Tech - CSE)",
  location: "Jaipur, India",
  email: "ajaybagherwal@gmail.com",
  linkedin: "https://www.linkedin.com/in/YOUR_LINKEDIN",
  github: "https://github.com/YOUR_GITHUB",
  tagline: "B.Tech Student | AI & Technology Enthusiast",
  about: "I am a B.Tech student interested in technology, artificial intelligence, web development and digital productivity. I am learning modern technologies and building practical projects.",
  stats: [
    { label: "Degree Path", value: "B.Tech CSE" },
    { label: "University", value: "JECRC Univ." },
    { label: "Core Focus", value: "AI & Web Dev" },
    { label: "Location", value: "Jaipur, India" }
  ]
};

export const educationData = [
  {
    degree: "Bachelor of Technology (B.Tech - Computer Science & Engineering)",
    college: "JECRC UNIVERSITY, Jaipur",
    location: "Jaipur, India",
    year: "2023 - 2027",
    status: "Currently Pursuing (Undergraduate)",
    badge: "B.Tech CSE",
    description: "Immersed in computer science foundations, algorithm design, software engineering methodologies, and cutting-edge artificial intelligence coursework.",
    highlights: [
      "Data Structures & Algorithms",
      "Artificial Intelligence & Generative AI",
      "Modern Web Development (HTML, CSS, JS, React)",
      "Database Management Systems & Architecture",
      "Digital Productivity & Workflow Automation"
    ]
  }
];

export const skillsData = [
  {
    name: "Artificial Intelligence",
    category: "AI & Emerging Tech",
    level: "Intermediate",
    proficiency: 82,
    description: "Core AI concepts, machine learning algorithms, model evaluation, and intelligent problem solving.",
    icon: "Brain"
  },
  {
    name: "Generative AI",
    category: "AI & Emerging Tech",
    level: "Intermediate",
    proficiency: 85,
    description: "Prompt engineering, LLM API integration, retrieval workflows, and AI-assisted application development.",
    icon: "Sparkles"
  },
  {
    name: "Python",
    category: "Programming",
    level: "Advanced",
    proficiency: 88,
    description: "Object-oriented programming, data structures, automation scripting, and AI/ML libraries.",
    icon: "FileCode2"
  },
  {
    name: "JavaScript",
    category: "Programming",
    level: "Proficient",
    proficiency: 85,
    description: "Modern ES6+ syntax, asynchronous programming, DOM manipulation, and interactive web logic.",
    icon: "Code"
  },
  {
    name: "Web Development",
    category: "Web & Frontend",
    level: "Proficient",
    proficiency: 86,
    description: "Full frontend lifecycle, component-driven UI architectures, responsive design, and performance tuning.",
    icon: "Globe"
  },
  {
    name: "HTML",
    category: "Web & Frontend",
    level: "Mastery",
    proficiency: 92,
    description: "Semantic HTML5 architecture, accessibility (a11y), clean document structure, and modern standards.",
    icon: "Layout"
  },
  {
    name: "CSS",
    category: "Web & Frontend",
    level: "Advanced",
    proficiency: 90,
    description: "CSS3, Tailwind CSS, Flexbox, CSS Grid, Glassmorphism, animations, and fluid mobile-first layouts.",
    icon: "Palette"
  },
  {
    name: "Digital Productivity",
    category: "Tools & Systems",
    level: "Advanced",
    proficiency: 90,
    description: "Systematic workflows, task automation, Notion architectures, Git/GitHub, and focused time management.",
    icon: "Zap"
  }
];

export const projectsData = [
  {
    id: 1,
    title: "Personal Portfolio Website",
    tagline: "Modern High-Performance Developer Portfolio",
    description: "A fast, responsive, and visually captivating portfolio website built with React and Tailwind CSS. Features glassmorphism, responsive navigation, dark tech aesthetics, and seamless Vercel deployment.",
    detailedDescription: "Designed from the ground up for modern web standards. Employs component-driven React architecture, Tailwind CSS utility styling with custom glassmorphic cards, smooth scrolling anchor links, accessible mobile drawer navigation, and instant email copy functionality.",
    technologies: ["React", "Vite", "Tailwind CSS", "JavaScript", "Lucide Icons", "Vercel"],
    category: "Web Development",
    featured: true,
    highlights: [
      "100% responsive across mobile, tablet, and widescreen devices",
      "Glassmorphic design with subtle glow animations and high contrast",
      "Organized modular code structure ready for continuous Vercel deployment",
      "Interactive project preview modals and one-click contact utilities"
    ],
    liveUrl: "#",
    githubUrl: "https://github.com/onik-bagherwal"
  },
  {
    id: 2,
    title: "AI Website Project",
    tagline: "Intelligent Web Assistant & Smart Prompt System",
    description: "An interactive web platform that harnesses Artificial Intelligence and Generative AI to deliver real-time automated insights, smart assistance, and interactive prompt workflows.",
    detailedDescription: "Built to explore practical integration of Generative AI models into web interfaces. Features dynamic prompt crafting, contextual conversational streaming, structured response formatting, and responsive UX tailored for students and knowledge workers.",
    technologies: ["React", "Python", "Generative AI", "LLM APIs", "Tailwind CSS", "REST APIs"],
    category: "Artificial Intelligence",
    featured: true,
    highlights: [
      "Interactive prompt engineering interface with instant AI responses",
      "Dynamic response streaming with markdown and code syntax highlighting",
      "Custom parameter controls for AI output length and creativity",
      "Clean dark UI designed for prolonged student research sessions"
    ],
    liveUrl: "#",
    githubUrl: "https://github.com/onik-bagherwal"
  },
  {
    id: 3,
    title: "Student Productivity Project",
    tagline: "Smart Workspace & Focus Tracking System",
    description: "A digital productivity application crafted specifically for university students to manage study schedules, prioritize coursework tasks, and maintain peak focus using integrated timers.",
    detailedDescription: "Designed to tackle academic overload through structured daily workflows. Integrates an intuitive task board with priority sorting, Pomodoro study interval timers, progress tracking analytics, and local persistence for offline reliability.",
    technologies: ["React", "JavaScript", "Tailwind CSS", "LocalStorage", "Productivity Systems"],
    category: "Digital Productivity",
    featured: true,
    highlights: [
      "Pomodoro study timer with customizable intervals and audio alerts",
      "Kanban-inspired task prioritization with persistent local storage",
      "Daily study goal checklist with dynamic completion percentage tracking",
      "Lightweight, distraction-free interface optimized for quick daily check-ins"
    ],
    liveUrl: "#",
    githubUrl: "https://github.com/onik-bagherwal"
  }
];

export const achievementsData = [
  {
    id: 1,
    title: "AI & Machine Learning Foundations",
    issuer: "Online Certification / Coursework",
    category: "Certifications",
    date: "2024",
    description: "Mastered core artificial intelligence principles, algorithmic problem solving, model training concepts, and evaluation metrics.",
    icon: "Award"
  },
  {
    id: 2,
    title: "Modern Web Development Bootcamp",
    issuer: "Technical Mastery Course",
    category: "Courses",
    date: "2024",
    description: "Comprehensive hands-on training across HTML5, CSS3, ES6+ JavaScript, modern component libraries, and responsive UI/UX principles.",
    icon: "BookOpen"
  },
  {
    id: 3,
    title: "University Tech Hackathon Participant",
    issuer: "JECRC University",
    category: "Hackathons",
    date: "2024",
    description: "Collaborated in an intensive sprint to prototype innovative software solutions addressing digital learning and student engagement.",
    icon: "Trophy"
  },
  {
    id: 4,
    title: "Digital Productivity & Workflow Systems",
    issuer: "Specialized Course",
    category: "Courses",
    date: "2023 - 2024",
    description: "Explored personal knowledge management systems, time-blocking techniques, and automation for engineering students.",
    icon: "CheckCircle2"
  },
  {
    id: 5,
    title: "Academic & Technical Excellence",
    issuer: "JECRC University",
    category: "Awards",
    date: "2023 - Present",
    description: "Recognized for consistent academic diligence, active technical learning, and commitment to practical project development.",
    icon: "Medal"
  },
  {
    id: 6,
    title: "Community Tech & Open Knowledge Contributor",
    issuer: "Developer Communities & Peer Learning",
    category: "Other Achievements",
    date: "2024",
    description: "Active contributor to student developer circles, sharing notes on generative AI tools, coding best practices, and developer efficiency.",
    icon: "Sparkles"
  }
];
